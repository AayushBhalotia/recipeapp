export const increment =()=>{
    return{
        type:"increment"
    };
}
export const dncrement =()=>{
    return{
        type:"decrement"
    };
}