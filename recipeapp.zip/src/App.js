import React from 'react';
import Main from "../src/html/Main";

function App(){

    return(
    <div className="App">
        <Main></Main>
    </div>    
    
    );
};

export default App;